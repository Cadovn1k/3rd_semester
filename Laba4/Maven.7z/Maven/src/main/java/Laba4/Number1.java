package Laba4;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;


public class Number1 {

    public static void main(String[] args) {
        try {
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonPers = (JSONObject) jsonParser.parse(new FileReader("Literature.json"));
            JSONArray jsonAuthors = (JSONArray) jsonPers.get("authors");
            JSONObject allauthors = new JSONObject();
            JSONArray forauthors = new JSONArray();
            for (int i = 0; i < jsonAuthors.size(); i++) {
                JSONObject author = (JSONObject) jsonAuthors.get(i);
                JSONObject huh = new JSONObject();
                System.out.println("Имя автора : " + author.get("name"));
                System.out.println("Написанные им книги : ");
                JSONArray jsonbooks = (JSONArray) author.get("books");
                JSONArray hah = new JSONArray();
                for (int j = 0; j < jsonbooks.size(); j++) {
                    JSONObject nob = (JSONObject) jsonbooks.get(j);
                    JSONObject nn = new JSONObject();
                    nn.put("nob", nob.get("nob"));
                    nn.put("pages", nob.get("pages"));
                    System.out.println("Название : " + nob.get("nob") + ", страниц : " + nob.get("pages"));
                    hah.add(nn);
                }
                if (author.get("name").equals("Толстой Л.Н.")){
                    JSONObject objT1 = new JSONObject();
                    objT1.put("nob", "Анна Каренина");
                    objT1.put("pages", "800");
                    JSONObject objT2 = new JSONObject();
                    objT2.put("nob", "Хаджи-Мурат");
                    objT2.put("pages", "25");
                    hah.add(objT1);
                    hah.add(objT2);
                }
                huh.put("books", hah);
                huh.put("name", author.get("name"));
                forauthors.add(huh);
            }

            JSONObject objG = new JSONObject();
            JSONArray bksG = new JSONArray();
            JSONObject bb = new JSONObject();
            bb.put("nob", "Детство");
            bb.put("pages", "808");
            bksG.add(bb);
            objG.put("books", bksG);
            objG.put("name", "Максим Горький");

            forauthors.add(objG);
            allauthors.put("authors", forauthors);
//            System.out.println(allauthors);  // для проверки
            FileWriter fw = new FileWriter("Literature.json", false);
            fw.write(String.valueOf(allauthors));
            fw.flush();
            fw.close();

            jsonPers = (JSONObject) jsonParser.parse(new FileReader("Literature.json"));
            jsonAuthors = (JSONArray) jsonPers.get("authors");
            System.out.println("Выписываем только имена авторов ");
            for (int i = 0; i < jsonAuthors.size(); i++) {
                JSONObject author = (JSONObject) jsonAuthors.get(i);
                System.out.println("Имя автора : " + author.get("name"));
            }

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        }
    }
}