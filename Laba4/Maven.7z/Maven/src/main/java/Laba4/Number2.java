package Laba4;

import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.json.XML;


public class Number2 {
    public static void main(String[] args) {
        try {
            BufferedReader r = new BufferedReader(new FileReader("sportmans.xml"));
            String str = "";
            String s = "";
            while ((s = r.readLine()) != null) {
                str += s;
            }
            JSONObject jsonObject = XML.toJSONObject(str);
            String jsonPrettyPrintString = jsonObject.toString(4);
//            System.out.println(jsonPrettyPrintString);
            File file = new File("sportmans.json");
            FileWriter fw = new FileWriter("sportmans.json", false);
            fw.write(jsonPrettyPrintString);
            fw.flush();
            fw.close();

            System.out.println("Выводим всех спортсменов по алфавиту");
            JSONParser jsonParser = new JSONParser();
            org.json.simple.JSONObject jsonPers = (org.json.simple.JSONObject) jsonParser.parse(new FileReader("sportmans.json"));
            org.json.simple.JSONObject jsonTeam = (org.json.simple.JSONObject) jsonPers.get("team");
            JSONArray jsonSportsman = (JSONArray) jsonTeam.get("sportsman");
            ArrayList<String> words = new ArrayList<String>();
            for (int i = 0; i < jsonSportsman.size(); i++) {
                org.json.simple.JSONObject sportsman = (org.json.simple.JSONObject) jsonSportsman.get(i);
                words.add(sportsman.get("name").toString());
            }
            Collections.sort(words);
            for (int k = 0; k < jsonSportsman.size(); k++) {
                for (int i = 0; i < jsonSportsman.size(); i++) {
                    org.json.simple.JSONObject sportsman = (org.json.simple.JSONObject) jsonSportsman.get(i);
                    if (words.get(k).equalsIgnoreCase(sportsman.get("name").toString())) {
                        System.out.println("Имя спортсмена : " + sportsman.get("name") +
                                ", пол : " + sportsman.get("s") + ", дата рождения : " + sportsman.get("birthday"));
                        if (!sportsman.get("name").equals("kolya")) {
                            JSONArray events = (JSONArray) sportsman.get("event");
                            System.out.println("Участие в соревнованиях : ");
                            for (int j = 0; j < events.size(); j++) {
                                org.json.simple.JSONObject ev = (org.json.simple.JSONObject) events.get(j);
                                System.out.println("Город : " + ev.get("place") + ", год : " + ev.get("year") +
                                        ", результат : " + ev.get("result") + ", медаль : " + ev.get("award"));
                            }
                        } else {
                            org.json.simple.JSONObject kolya = (org.json.simple.JSONObject) sportsman.get("event");
                            System.out.println("Город : " + kolya.get("place") + ", год : " + kolya.get("year") +
                                    ", результат : " + kolya.get("result") + ", медаль : " + kolya.get("award"));
                        }
                        System.out.println();
                    }
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

}
