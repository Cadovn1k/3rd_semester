package Laba4;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;

// начинает работать после запуска 2го номера, так как там создается необходимый json файл
public class Number3 {
    public static void main(String[] args) {
        try {
            JSONParser jsonParser = new JSONParser();

            org.json.simple.JSONObject jsonPers = (org.json.simple.JSONObject) jsonParser.parse(new FileReader("sportmans.json"));
            org.json.simple.JSONObject jsonTeam = (org.json.simple.JSONObject) jsonPers.get("team");
            JSONArray jsonSportsman = (JSONArray) jsonTeam.get("sportsman");
            JSONObject allsportmans = new JSONObject();
            JSONArray forasportmans = new JSONArray();
            for (int i = 0; i < jsonSportsman.size(); i++) {
                JSONObject sportsman = (JSONObject) jsonSportsman.get(i);
                JSONObject huh = new JSONObject();
                huh.put("name", sportsman.get("name"));
                huh.put("birthday", sportsman.get("birthday"));
                huh.put("gender", sportsman.get("s"));
                huh.put("name", sportsman.get("name"));
                forasportmans.add(huh);
            }

            allsportmans.put("sportmans", forasportmans);

            JSONObject team = new JSONObject();
            team.put("team", allsportmans);

            File file = new File("SL_sportmans.json");
            FileWriter fw = new FileWriter("SL_sportmans.json", false);
            fw.write(String.valueOf(team));
            fw.flush();
            fw.close();

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        }
    }
}
