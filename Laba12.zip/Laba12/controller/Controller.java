package sample.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.pojo.User;
import javafx.scene.control.TableColumn;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;

public class Controller {

    private ObservableList<User> usersData = FXCollections.observableArrayList();

    @FXML
    private TableView<User> tableUsers;

    @FXML
    private TableColumn<User, LocalDate> dateColumn;

    @FXML
    private TableColumn<User, Integer> temperatureColumn;

    // инициализируем форму данными
    @FXML
    private void initialize() {
        initData();

        // устанавливаем тип и значение которое должно хранится в колонке
        dateColumn.setCellValueFactory(new PropertyValueFactory<User, LocalDate>("Date"));
        temperatureColumn.setCellValueFactory(new PropertyValueFactory<User, Integer>("Temperature"));

        // заполняем таблицу данными
        tableUsers.setItems(usersData);
    }

    // подготавливаем данные для таблицы
    private void initData() {
        String str = "";
        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Admin\\IdeaProjects\\My_javafx_project\\src\\temp2.csv"))) {
            // читаем посимвольно
            while ((str = reader.readLine()) != null) {
                usersData.add(new User(LocalDate.of(Integer.parseInt((str.substring(6, 10))), Integer.parseInt(str.substring(3, 5)), Integer.parseInt(str.substring(0, 2))), Integer.parseInt(str.substring(11))));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}