package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import sample.pojo.User;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;


public class Main extends Application {

    public Main() throws IOException {
    }

    @Override
    public void start(Stage stage) throws Exception {
//// Номер 1 А
//        CategoryAxis xAxis = new CategoryAxis();
//        xAxis.setLabel("Фамилия");
//
//        NumberAxis yAxis = new NumberAxis();
//        yAxis.setLabel("рост, вес");
//
//        BarChart<String, Number> barChart = new BarChart<String, Number>(xAxis, yAxis);
//
//        XYChart.Series<String, Number> ds1 = new XYChart.Series<String, Number>();
//        ds1.setName("Рост");
//
//        ds1.getData().add(new XYChart.Data<String, Number>("Шишов", 142));
//        ds1.getData().add(new XYChart.Data<String, Number>("Мокроносов", 168));
//        ds1.getData().add(new XYChart.Data<String, Number>("Кулебякина", 150));
//        ds1.getData().add(new XYChart.Data<String, Number>("Букоедов", 180));
//
//        XYChart.Series<String, Number> ds2 = new XYChart.Series<String, Number>();
//        ds2.setName("Вес");
//
//        ds2.getData().add(new XYChart.Data<String, Number>("Шишов", 41));
//        ds2.getData().add(new XYChart.Data<String, Number>("Мокроносов", 60));
//        ds2.getData().add(new XYChart.Data<String, Number>("Кулебякина", 44));
//        ds2.getData().add(new XYChart.Data<String, Number>("Букоедов", 75));
//
//        barChart.getData().add(ds1);
//        barChart.getData().add(ds2);
//
//        barChart.setTitle("Гистограмма с данными из таблицы");
//
//        VBox vbox = new VBox(barChart);
//
//        stage.setTitle("");
//        Scene scene = new Scene(vbox, 400, 200);
//
//        stage.setScene(scene);
//        stage.setHeight(300);
//        stage.setWidth(400);
//
//        stage.show();

//----------------------------------------------------------------------------------------------------------
//// Номер 1 Б
//        NumberAxis x = new NumberAxis();
//        NumberAxis y = new NumberAxis();
//        LineChart<Number, Number> barChart = new LineChart<Number, Number>(x, y);
//        barChart.getXAxis().setLabel("x");
//        barChart.getYAxis().setLabel("y");
//        barChart.setTitle("Series");
//
//        XYChart.Series series = new XYChart.Series();
//        series.setName("sin(x)");
//        ObservableList<XYChart.Data> datas = FXCollections.observableArrayList();
//
//        for (double i = -2 * Math.PI; i < 2 * Math.PI; i += 0.1) {
//            if (i < Math.PI / 2 && i > -Math.PI / 2) {
//                datas.add(new XYChart.Data<>(i, Math.sin(2 * i)));
//            }
//            if (i <= -Math.PI / 2) {
//                datas.add(new XYChart.Data<>(i, 1 / i));
//            }
//            if (i >= Math.PI / 2) {
//                datas.add(new XYChart.Data<>(i, Math.sqrt((Math.pow(i, 3) - 1))));
//            }
//
//        }
//
//        series.setData(datas);
//        barChart.setLegendVisible(false);
//        barChart.setCreateSymbols(false);
//        barChart.getData().add(series);
//
//        VBox vbox = new VBox(barChart);
//
//        stage.setTitle("");
//        Scene scene = new Scene(vbox, 400, 200);
//        scene.getStylesheets().add("style.css");
//        stage.setScene(scene);
//        stage.setHeight(300);
//        stage.setWidth(400);
//
//        stage.show();
//----------------------------------------------------------------------------------------------------------
// // Номер 2,1 а
//        Parent root = FXMLLoader.load(getClass().getResource("views/main.fxml"));
//        stage.setTitle("Weather");
//        stage.setScene(new Scene(root));
//        stage.show();
//----------------------------------------------------------------------------------------------------------
        //// Номер 2.2 А
//        NumberAxis x = new NumberAxis();
//        NumberAxis y = new NumberAxis();
//        LineChart<Number, Number> barChart = new LineChart<Number, Number>(x, y);
//        barChart.getXAxis().setLabel("День");
//        barChart.getYAxis().setLabel("Температура");
//        barChart.setTitle("Данные за апрель");
//
//        XYChart.Series series = new XYChart.Series();
//        series.setName("");
//        ObservableList<XYChart.Data> datas = FXCollections.observableArrayList();
//        int[] tempforapril = new int[31];
//        String str = "";
//        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Admin\\IdeaProjects\\My_javafx_project\\src\\temp2.csv"))) {
//            while ((str = reader.readLine()) != null) {
//                if (Integer.parseInt(str.substring(3, 5)) == 4) {
//                    tempforapril[Integer.parseInt(str.substring(0, 2))] = Integer.parseInt(str.substring(11));
//                }
//            }
//        } catch (IOException ex) {
//            System.out.println(ex.getMessage());
//        }
//        for (int i = 1; i <= 30; i++) {
//            datas.add(new XYChart.Data<>(i, tempforapril[i]));
//        }
//
//        series.setData(datas);
//        barChart.setLegendVisible(false);
//        barChart.setCreateSymbols(false);
//        barChart.getData().add(series);
//
//        VBox vbox = new VBox(barChart);
//
//        stage.setTitle("");
//        Scene scene = new Scene(vbox, 400, 200);
//        scene.getStylesheets().add("style.css");
//        stage.setScene(scene);
//        stage.setHeight(300);
//        stage.setWidth(400);
//
//        stage.show();

        // 2.2 Б
//        NumberAxis x = new NumberAxis();
//        NumberAxis y = new NumberAxis();
//        LineChart<Number, Number> barChart = new LineChart<Number, Number>(x, y);
//        barChart.getXAxis().setLabel("День");
//        barChart.getYAxis().setLabel("Температура");
//        barChart.setTitle("Данные за год");
//
//        XYChart.Series series = new XYChart.Series();
//        series.setName("");
//        ObservableList<XYChart.Data> datas = FXCollections.observableArrayList();
//        String str = "";
//        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Admin\\IdeaProjects\\My_javafx_project\\src\\temp2.csv"))) {
//            int days = 1;
//            while ((str = reader.readLine()) != null) {
//                datas.add(new XYChart.Data<>(days, Integer.parseInt(str.substring(11))));
//                days++;
//            }
//        } catch (IOException ex) {
//            System.out.println(ex.getMessage());
//        }
//
//        series.setData(datas);
//        barChart.setLegendVisible(false);
//        barChart.setCreateSymbols(false);
//        barChart.getData().add(series);
//
//        VBox vbox = new VBox(barChart);
//
//        stage.setTitle("");
//        Scene scene = new Scene(vbox, 400, 200);
//        scene.getStylesheets().add("style.css");
//        stage.setScene(scene);
//        stage.setHeight(300);
//        stage.setWidth(400);
//
//        stage.show();

        // 2.2 В
//        NumberAxis x = new NumberAxis();
//        NumberAxis y = new NumberAxis();
//        LineChart<Number, Number> barChart = new LineChart<Number, Number>(x, y);
//        barChart.getXAxis().setLabel("День");
//        barChart.getYAxis().setLabel("Температура");
//        barChart.setTitle("Данные за год");
//
//        XYChart.Series series = new XYChart.Series();
//        series.setName("");
//        ObservableList<XYChart.Data> datas = FXCollections.observableArrayList();
//        int[] permonth = new int[13];
//        int ss = 0;
//        int month = 1;
//        String str = "";
//        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Admin\\IdeaProjects\\My_javafx_project\\src\\temp2.csv"))) {
//            int days = 1;
//            while ((str = reader.readLine()) != null) {
//                if (str.substring(0, 2).equals("01") && days != 1){
//                    permonth[month] = ss/(days - 1);
//                    month++;
//                    days = 1;
//                    ss = 0;
//                }
//                ss += Integer.parseInt(str.substring(11));
//                days++;
//            }
//
//            for (int i = 1; i < permonth.length; i++) {
//                datas.add(new XYChart.Data<>(i, permonth[i]));
//            }
//        } catch (IOException ex) {
//            System.out.println(ex.getMessage());
//        }
//
//        series.setData(datas);
//        barChart.setLegendVisible(false);
//        barChart.setCreateSymbols(false);
//        barChart.getData().add(series);
//
//        VBox vbox = new VBox(barChart);
//
//        stage.setTitle("");
//        Scene scene = new Scene(vbox, 400, 200);
//        scene.getStylesheets().add("style.css");
//        stage.setScene(scene);
//        stage.setHeight(300);
//        stage.setWidth(400);
//
//        stage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}

